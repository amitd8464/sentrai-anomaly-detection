import LogsTable from '../components/LogsTable';

export default function Logs() {
  return <LogsTable />;
}
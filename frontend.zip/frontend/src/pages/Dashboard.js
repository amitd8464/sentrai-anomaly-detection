import HealthStatus from '../components/HealthStatus';

export default function Dashboard() {
  return <HealthStatus />;
}
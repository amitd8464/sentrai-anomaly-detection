import React from 'react';
import './Topbar.css';

export default function Topbar() {
  return (
    <div className="topbar">
      <span>Anomaly Detection System</span>
    </div>
  );
}
